import java.util.Stack;
import java.util.Random;
import javax.sound.midi.Soundbank;

 

public class Game {
    private Parser parser;
    private Room currentRoom;
    private Stack<Room> oldRooms = new Stack<>();
    private Player player = new Player();
    Random numero = new Random();
    private int localGuitarra;
    private int numAleatorio;
   

    /**
     * Criação e inicialização do mapa do jogo.
     */
    public Game() {
        createRooms();
        parser = new Parser();
    }

    /**
     * Criação de todas as salas presentes no jogo.
     */
    private void createRooms() {
        Room camarim, palco, sala1, sala2, sala3, sala4, sala5, sala6, sala7, sala8, sala9, sala10,
        corredor1, corredor2, corredor3, corredor4, corredor5, corredor6, corredor7, corredor8;

        // Criar as salas
        camarim = new Room("Camarim dos artistas juntamente com Fabian, Freddie, Brian, Roger, John.");
        palco = new Room("Palco do show");
        sala1 = new Room("Sala dos fundos: Loja");
        corredor1 = new Room("Corredor em frente ao camarim.");
        sala2 = new Room("Sala dos fundos: Vestiario geral");
        corredor2 = new Room("Corredor entre sala 2 e 3");
        sala3 = new Room("Sala dos fundos: Banheiro masculino");
        corredor3 = new Room("Corredor entre sala 1 e 4");
        sala4 = new Room("Sala dos fundos: Banheiro feminino");
        corredor4 = new Room("Corredor entre sala 5 e palco");
        sala5 = new Room("Sala dos fundos: ");
        corredor5 = new Room("Corredor entre sala 6 e 10");
        sala6 = new Room("Sala dos fundos: ");
        corredor6 = new Room("Corredor entre sala 7,8 e 9");
        sala7 = new Room("Sala dos fundos: ");
        corredor7 = new Room("Corredor entre sala 3, 5 e 6.\nSala3: Oeste.\nSala5: Norte.\nSala6: Leste.");
        sala8 = new Room("Sala dos fundos: ");
        corredor8 = new Room("Antes do 2 e 3");
        sala9 = new Room("Sala dos fundos: ");
        sala10 = new Room("Sala dos fundos: ");        

        // Iniciar as salas
        camarim.setExit("frente", corredor1);
        palco.setExit("trás", corredor4);
        sala1.setExit("trás", corredor3);
        sala2.setExit("trás", corredor2);
        sala3.setExit("esquerda", corredor2);
        sala3.setExit("direita", corredor7);
        sala4.setExit("trás", corredor3);
        sala5.setExit("frente", corredor4);
        sala5.setExit("trás", corredor7);
        sala6.setExit("esquerda", corredor7);
        sala6.setExit("trás", sala7);
        sala7.setExit("frente", sala6);
        sala8.setExit("trás", corredor6);
        sala9.setExit("trás", corredor6);
        sala10.setExit("trás", corredor5);

        corredor1.setExit("frente", corredor7);
        corredor1.setExit("direita", corredor6);
        corredor1.setExit("esquerda", corredor8);

        corredor8.setExit("direita", corredor1);
        corredor8.setExit("frente", corredor2);

        corredor2.setExit("direita", sala3);
        corredor2.setExit("esquerda", sala2);
        corredor2.setExit("frente", corredor3);

        corredor3.setExit("direita", corredor4);
        corredor3.setExit("frente", sala4);
        corredor3.setExit("esquerda", sala1);

        corredor4.setExit("frente", palco);
        corredor4.setExit("direita", corredor5);
        corredor4.setExit("esquerda", corredor3);

        corredor5.setExit("direita", sala10);
        corredor5.setExit("esquerda", corredor4);

        corredor6.setExit("direita", sala9);
        corredor6.setExit("frente", corredor5);
        corredor6.setExit("esquerda", corredor1);

        corredor7.setExit("direita", sala6);
        corredor7.setExit("frente", sala5);
        corredor7.setExit("esquerda", sala3);

        currentRoom = camarim; // Começa o jogo no camarim

        presetItems(sala1, sala2, sala3, sala4, sala5, sala6, sala7, sala8, sala9, sala10);
        
    }

    /**
     * Rotina de jogo principal. Loops até o final do jogo.
     */
    public void play() {
        printWelcome();

       // Loop principal do jogo, que persiste até o fim.

        boolean finished = false;
        while (!finished) {
            Command command = parser.getCommand();
            finished = processCommand(command);
        }
        //System.out.println("Volte assim que puder!"); 
    }

    /**
* Exibe a mensagem inicial para o player.
*/
    private void printWelcome() {
        System.out.println();
        System.out.println("Bem vindos ao The Show Must Go On!");
        System.out.println("Hoje é o dia do GRANDE SHOW!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        System.out.println("Você, o braço direito da banda, está nesse momento escutando uma bronca do empresário:");
        System.out.println("Jorge: COMO QUE ESSES PASPALHOS VÃO TOCAR NO SHOW SE ELES NÃO SABEM ONDE ESTÃO A DROGA DOS INSTRUMENTOS!!!");
        System.out.println("Jorge: Cris, você como ajudante da banda vai achar esses instrumentos pelos bastidores e deixa-los no palco AGORA!");
        System.out.println("Jorge: Aproveite que todos os paspalhos estão no camarim e pergunte se eles pelo menos lembram onde deixaram os instrumentos.");
        System.out.println("Jorge: Estou indo embora. Qualquer dúvida maior só digitar \"Ajuda\".");
        printLocationInfo();
    }

     // Processamento dos comandos feitos pelo jogador.

    private boolean processCommand(Command command) {
        boolean wantToQuit = false;
        System.out.println("\n");
        if (command.isUnknown()) {
            System.out.println("Não entendi o que você falou...");
            System.out.println("Os comandos são: ");
            parser.showCommands();
            return false;
        }
        String commandWord = command.getCommandWord();
        if (commandWord.equalsIgnoreCase("Ajuda")) {
            printHelp();
        } else if (commandWord.equalsIgnoreCase("Ir")) {
            goRoom(command);
        } else if (commandWord.equalsIgnoreCase("Sair")) {
            wantToQuit = quit(command);
        }else if(commandWord.equalsIgnoreCase("Olhar")){
            printLocationInfo();
        }else if(commandWord.equalsIgnoreCase("Voltar")){
            goRoom(command);
        }else if(commandWord.equalsIgnoreCase("Pegar")){
           takeItem(command);
        }else if(commandWord.equalsIgnoreCase("Soltar")){
            dropItem(command);
        }else if(commandWord.equalsIgnoreCase("Itens")){
            String items = player.getItems();
            System.out.println(items);
        }else if(commandWord.equalsIgnoreCase("Dica")){
            pedirDica(command);
        }

        return wantToQuit;
    }

   /**
 * Exibe informações iniaciais de ajuda.
 **/
 

    private void printHelp() {
        System.out.println("Me parece que você está perdido pelos bastidores.");
        System.out.println("É realmente bem grande...");
        System.out.println();
        System.out.println("Os comandos disponíveis são:");
        parser.showCommands();
    }

    /**
     Exibe uma mensagem de erro caso não haja outra sala para entrar.
     */
    private void goRoom(Command command) {
        if(command.getCommandWord().equals("Voltar")){
            if(oldRooms.size() == 0){
                System.out.println("Já voltou todas as salas que você andou."); 
                return; 
            }else{      
                currentRoom = oldRooms.pop();
                printLocationInfo();
                return;
            }

        }else if (!command.hasSecondWord()) {
            // Esse comando pede para que o usuario especifique a direção a seguir...
            System.out.println("O comando \"Ir\" é seguido de \"para\" e a direção.");
            return;
        }else if(!command.hasThirdWord()){
            System.out.println("Ir para onde?");
            return;
        }

        String direction = command.getThirdWord();
        System.out.println(direction);
        direction = direction.toLowerCase();
        char letra = direction.charAt(2);
        System.out.println(letra);
        if(letra == ' ')
            direction = "trás";
        System.out.println(direction);
        // Sair da sala atual
        Room nextRoom = currentRoom.getExit(direction);

        if (nextRoom == null) {
            System.out.println("Não tem saída para esse sentido...");
        }else {
            oldRooms.push(currentRoom); 
            currentRoom = nextRoom;     
            printLocationInfo();
        }
    }

    /**
     Comando para sair do game...
     */
    private boolean quit(Command command) {
        if (command.hasSecondWord()) {
            System.out.println("Para sair do jogo digite apenas \"Sair\".");
            return false;
        } else {
            return true; // sinalizar para sair 
        }
    }

    private void printLocationInfo() {
        System.out.println(currentRoom.getLongDescription());
    }

    private void takeItem(Command command){
        if (!command.hasSecondWord()) {
            // Comando para que o usuario especifique o item...
            System.out.println("Qual item?");
            return;
        }

        String secondWord = command.getSecondWord();
        Item itemRoom = currentRoom.getItem(secondWord);

        if (itemRoom == null) {
            System.out.println("Item nao existe na sala!");
            return;
        }
        
        //currentRoom.perdeItem(secondWord);

        if(player.getItem(secondWord) != null){
            player.takeItem(secondWord);
            if(!player.teste())
                currentRoom.perdeItem(secondWord);
        }else{
            player.createItem(itemRoom.getDescription(), itemRoom.getWeight(), 1, secondWord);
            if(!player.teste())
                currentRoom.perdeItem(secondWord);
        }

        String itemsOfPlayer = player.getItems();
        String itemsOfRoom = currentRoom.getItems();
        System.out.println(itemsOfPlayer + "\n" + itemsOfRoom);

    }

    private void dropItem(Command command){
        if (!command.hasSecondWord()) {
           // Comando para que o usuario especifique o item...
            System.out.println("Qual item?");
            return;
        }

        String secondWord = command.getSecondWord();
        Item itemPlayer = player.getItem(secondWord);

        if(itemPlayer != null){
            player.dropItem(secondWord);
            if(!player.teste())
                currentRoom.ganhaItem(secondWord, itemPlayer);
        }else{
            System.out.println("O jogador nao possui este item.");
        }

        String itemsOfPlayer = player.getItems();
        String itemsOfRoom = currentRoom.getItems();
        System.out.println(itemsOfPlayer + "\n" + itemsOfRoom);

    }

    private void presetItems(Room sala1, Room sala2, Room sala3, Room sala4, Room sala5, Room sala6, Room sala7, Room sala8, Room sala9, Room sala10){
        
        sala5.createItem("Tambores da bateria do Roger", 10, 1, "Tambores"); // Facilitar, pois são duas viagens.
        sala5.createItem("Pratos da bateria do Roger", 10, 1, "Pratos da bateria"); 
        numAleatorio = numero.nextInt();

        switch (numAleatorio) {
            case 1:
                sala1.createItem("Guitarra do Brian", 10, 1, "Guitarra");
                sala3.createItem("Baixo do John", 10, 1, "Baixo");
                sala9.createItem("Teclado do Freddie", 10, 1, "Teclado");
                sala7.createItem("Mochila", 0, 1,"Mochila");
                //Guardando as salas dos instrumentos para ajudar no momento de dar a dica.
                localGuitarra = 1;
                break;
            case 2:
                sala4.createItem("Guitarra do Brian", 10, 1, "Guitarra");
                sala2.createItem("Baixo do John", 10, 1, "Baixo");
                sala7.createItem("Teclado do Freddie", 10, 1, "Teclado");
                sala10.createItem("Mochila", 0, 1,"Mochila");
                //Guardando as salas dos instrumentos para ajudar no momento de dar a dica.
                localGuitarra = 4;
                break;
            case 3:
                sala6.createItem("Guitarra do Brian", 10, 1, "Guitarra");
                sala7.createItem("Baixo do John", 10, 1, "Baixo");
                sala1.createItem("Teclado do Freddie", 10, 1, "Teclado");
                sala3.createItem("Mochila", 0, 1,"Mochila");
                //Guardando as salas dos instrumentos para ajudar no momento de dar a dica.
                localGuitarra = 6;
                break;
            case 4:
                sala7.createItem("Guitarra do Brian", 10, 1, "Guitarra");
                sala4.createItem("Baixo do John", 10, 1, "Baixo");
                sala3.createItem("Teclado do Freddie", 10, 1, "Teclado");
                sala2.createItem("Mochila", 0, 1,"Mochila");
                //Guardando as salas dos instrumentos para ajudar no momento de dar a dica.
                localGuitarra = 7;
                break;
            case 5: 
                sala10.createItem("Guitarra do Brian", 10, 1, "Guitarra");
                sala10.createItem("Baixo do John", 10, 1, "Baixo");
                sala10.createItem("Teclado do Freddie", 10, 1, "Teclado");
                sala10.createItem("Mochila", 0, 1,"Mochila");
                //Guardando as salas dos instrumentos para ajudar no momento de dar a dica.
                localGuitarra = 10;
                break;
        }        

    }

    private void pedirDica(Command command){

        String nome = command.getSecondWord();
        if (!currentRoom.getDescription().equals("Camarim dos artistas juntamente com Fabian, Freddie, Brian, Roger, John.")) { // Se não tiver a pessoa não tem como pedir a dica
            System.out.println("Os integrantes da banda estão apenas no camarim.");
            return;
        }else if(nome == null) { // Se não tiver a pessoa não tem como pedir a dica
            System.out.println("Para quem você quer pedir uma dica? Digite Dica e o nome em seguida.");
            return;
        }
        if(nome.equalsIgnoreCase("Fabian")){
            System.out.println("Fabian: Eu? Não precisa se preocupar comigo. O microfone jamais sai do palco.");
            if(numero.nextInt(2) == 0){
                System.out.println("Pra não falar que eu não ajudei, o palco está sempre ao norte, eu mesmo já me perdi por aqui algumas vezes...");
            }else{
                System.out.println("Tome cuidado que os instrumentos são pesados! Se eu fosse você carregaria um por vez.");
            }
        }else if(nome.equalsIgnoreCase("Freddie")){
            if(numero.nextInt(2) == 0){
                System.out.println("Freddie: Eu gosto muito daquele teclado, cara. Eu acredito nessas coisas de supertição sabe?! Só entro na sala com meu teclado se o número dela for ímpar.");
            }else{
                System.out.println("Freddie: Não encontrou nas salas ímpares? Talvez tenham pegado e deixado junto dos outros instrumentos em algum lugar...");
            }
        }else if(nome.equalsIgnoreCase("Brian")){
            if(localGuitarra > 5)
                System.out.println("Brian: Opa, Cris. Tranquilo? Acredita que eu finalmente aprendi o solo daquela música do MC Lan \"Rabetão\" sabe?! Ah, a guitarra... Acho que está pra direita daqui do camarim.");
            else
                System.out.println("Brian: Opa, Cris. Tranquilo? Acredita que eu finalmente aprendi o solo daquela música do MC Lan \"Rabetão\" sabe?! Ah, a guitarra... Acho que está pra esquerda daqui do camarim.");
        }else if(nome.equalsIgnoreCase("Roger")){
            System.out.println("Roger: Que? Você quer uma dica? Cris, me ajuda aí né... Se você só andar pra frente você já vai achar a bateria.");
        }else if(nome.equalsIgnoreCase("John")){
            System.out.println("John: Se você tiver vindo perguntar sobre o baixo eu tenho uma triste notícia pra você: Eu não lembro onde deixei rs.");
        }else{
            System.out.println("Não tem ninguém na sala com esse nome.");
            return;
        }

    }

}
    