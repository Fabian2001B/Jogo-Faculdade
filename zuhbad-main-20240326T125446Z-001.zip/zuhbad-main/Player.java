import java.util.HashMap;
import java.util.Set;

public class Player {

    private int limitWeight = 10;
    private int totalWeight = 0;
    private boolean excedeu = false;
    
    private HashMap<String, Item> itemsOfPlayer = new HashMap<>();

    public void takeItem(String name){
        excedeu = false;
        if(name.equals("Mochila")){
            limitWeight += 10;
        }
        // itemsOfPlayer.get(name).ganhaItem();
        updateWeight(name,true,itemsOfPlayer.get(name).getWeight());
        if(!excedeu)
            itemsOfPlayer.get(name).ganhaItem();

    }

    public void dropItem(String name){
        if(name.equals("Mochila")){
            excedeu = true;
            System.out.println("O que? Soltar a mochila? Com ela eu consigo carregar mais de um instrumento por vez. Não vou soltar!");
            return;
        }
        itemsOfPlayer.get(name).perderItem();
        updateWeight(name,false,itemsOfPlayer.get(name).getWeight());
        if(itemsOfPlayer.get(name).getAmount() == 0){
            itemsOfPlayer.remove(name);
        }
    }

    public String getItems(){
        Set<String> keys = itemsOfPlayer.keySet();
        String information = "";
        for(String key: keys){
            information += " "+key +":"+ itemsOfPlayer.get(key).getAmount();
        }
        return "Inventory: " + "\n"+ "Items of player: " + information + "\n"+ "Total weight: "+ totalWeight;
    }

    public Item getItem(String name){
        return itemsOfPlayer.get(name) != null ? itemsOfPlayer.get(name) : null;
    }

    private void setItem(String name, Item item) {
        if(name.equals("Mochila")){
            limitWeight += 10;
            itemsOfPlayer.put(name,item);
            System.out.println("Com a mochila eu vou conseguir carregar mais um instrumento.");
        }else{
            updateWeight(name,true, item.getWeight());
            if(!excedeu)
                itemsOfPlayer.put(name,item);
        }
    }

    public void createItem(String description, int weight, int amount, String name) {
        Item item = new Item(description, weight, amount);
        setItem(name, item);
    }

    private void updateWeight(String name, boolean add, int weight){
        if(add){
            if(totalWeight + weight > limitWeight){
                System.out.println("Muito pesado para mim.");
                excedeu = true;
            }else{
                totalWeight +=  weight;
            }

        }else{
            totalWeight -=  weight;
        }

    }

    public int getTotalWeight(){
        return totalWeight;
    }

    public int getLimitWeight(){
        return limitWeight;
    }

    public boolean teste(){
        return excedeu;
    }

}
